package com.example.parkit;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class signup extends AppCompatActivity {

    EditText fname,email2,phone,password;
    Button btnsignup;
    TextView lredirect;
    SQLiteDatabase mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        this.getSupportActionBar().hide();
        fname=(EditText) findViewById(R.id.sfullname);
        email2=(EditText) findViewById(R.id.semail);
        phone=(EditText) findViewById(R.id.sphone);
        password=(EditText) findViewById(R.id.spassword);
        btnsignup=(Button)findViewById(R.id.Btn_signup);
        lredirect=(TextView) findViewById(R.id.Glogin);
        mydb = openOrCreateDatabase("ParkDb", Context.MODE_PRIVATE, null);
        if (mydb != null)
        {
            Toast.makeText(this, "Created/Opened", Toast.LENGTH_SHORT).show();
        }
        mydb.execSQL("CREATE TABLE IF NOT EXISTS tbllogin(fname VARCHAR,email VARCHAR,phone VARCHAR,password VARCHAR);");

        btnsignup.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String name = fname.getText().toString();
                String email1 = email2.getText().toString();
                String mobile = phone.getText().toString();
                String pass = password.getText().toString();
                boolean valid=true;
                if (name.isEmpty() || name.length() < 3) {
                    fname.setError("at least 3 characters");
                    valid = false;
                } else {
                    fname.setError(null);
                }
                if (email1.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email1).matches()) {
                    email2.setError("enter a valid email address");
                    valid = false;
                } else {
                    email2.setError(null);
                }

                if (mobile.isEmpty() || mobile.length()!=10) {
                    phone.setError("Enter Valid Mobile Number");
                    valid = false;
                } else {
                    phone.setError(null);
                }

                if (pass.isEmpty() || password.length() < 4 || password.length() > 10) {
                    password.setError("between 4 and 10 alphanumeric characters");
                    valid = false;
                } else {
                    password.setError(null);
                }
                //return valid;
                if (valid==true) {
                    mydb.execSQL("INSERT INTO tbllogin VALUES('" + fname.getText() + "','" + email2.getText() +
                            "','" + phone.getText() + "','" + password.getText() + "');");
                    showMessage("Success", "Signup Successfull !");
                    clearText();
                    Intent in = new Intent(signup.this, login.class);
                    startActivity(in);
                }



            }
        });
        // lredirect.setOnClickListener(new View.OnClickListener()
        //{
        //  @Override
        //  public void onClick(View v)
        //  {
        //    Intent in=new Intent(signup.this,login.class);
        //    startActivity(in);
        //  }
        // });

    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText() {
        fname.setText("");
        email2.setText("");
        phone.setText("");
        password.setText("");
        fname.requestFocus();
    }

}

