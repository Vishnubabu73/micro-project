package com.example.parkit;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    LocationManager locationManager;
    private Circle mCircle;
    Marker marker;
    double currlat,currlong;
    LatLng selected;
    Button track;
    boolean alreadyExecuted=false;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        track=findViewById(R.id.btn_track);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        if(locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER))//if network is on this code works
        {
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, new LocationListener()
            {
                @Override
                public void onLocationChanged(Location location)
                {
                    //get the latitude
                    double latitude=location.getLatitude();

                    //get the longitude
                    double longitude=location.getLongitude();
                    //instantiate latitude longitude class to get latitude and longitude
                    LatLng latLng=new LatLng(latitude,longitude);



                    handleNewLocation(latLng);
                    track.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v)
                        {


                            initmarker(9.565387 ,76.754581);
                            initmarker(9.558360,76.791490);
                            initmarker(9.527877,76.828074);
                            initmarker(9.6600783,76.723118);
                            initmarker(9.603573,76.648961);
                            initmarker(9.533190,76.826343);
                            initmarker(9.502501,76.748055);
                            initmarker(9.711628,76.550097);
                            initmarker(9.548466,76.510973);
                            initmarker(9.579553,76.759533);
                            initmarker(9.49877,76.799391);
                            initmarker(9.4885311,76.736153);
                            initmarker(9.5454978,76.5260383);

                        }
                    });




                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {

                }

                @Override
                public void onProviderEnabled(String provider) {

                }

                @Override
                public void onProviderDisabled(String provider) {

                }
            });

        }
        else if(locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))//if only gps is available
        {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, new LocationListener() {
                @Override
                public void onLocationChanged(Location location)
                {




                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {

                }

                @Override
                public void onProviderEnabled(String provider) {

                }

                @Override
                public void onProviderDisabled(String provider) {

                }
            });

        }

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setScrollGesturesEnabled(true);
        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker)
            {
                Toast.makeText(getApplicationContext(),"Selected",Toast.LENGTH_SHORT).show();
                selected=marker.getPosition();
                Uri.Builder directionsBuilder = new Uri.Builder()
                        .scheme("https")
                        .authority("www.google.com")
                        .appendPath("maps")
                        .appendPath("dir")
                        .appendPath("")
                        .appendQueryParameter("api", "1")
                        .appendQueryParameter("destination", marker.getPosition().latitude + "," +marker.getPosition().longitude);
                startActivity(new Intent(Intent.ACTION_VIEW, directionsBuilder.build()));

                return false;
            }
        });

    }

    public void initmarker(double x,double y)
    {
        float calcdistance;
        calcdistance=distance(currlat,currlong,x,y);
        if(calcdistance<=10000.0)
        {
            LatLng ln=new LatLng(x,y);
            Geocoder geocoder=new Geocoder(getApplicationContext());
            try {
                List<Address>addressList=geocoder.getFromLocation(x,y,1);
                String locality=addressList.get(0).getLocality()+"  "+"Parking ";
                marker = mMap.addMarker(new MarkerOptions().position(ln).title(locality));

            }
            catch (IOException e) {
                e.printStackTrace();
            }



        }



    }

    private void handleNewLocation(LatLng latLng)
    {

        if(!alreadyExecuted)
        {
            marker=mMap.addMarker(new MarkerOptions().position(latLng).title("I am here!"));
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,10.5f));
            mCircle = mMap.addCircle(new CircleOptions()
                    .center(latLng)
                    .radius(150)
                    .strokeColor(Color.BLUE)
                    .fillColor(Color.GREEN)
                    .strokeWidth(10));
            currlat=latLng.latitude;
            currlong=latLng.longitude;
            alreadyExecuted=true;
        }

    }



    public float distance (double lat_a, double lng_a, double lat_b, double lng_b )
    {
        double earthRadius = 3958.75;
        double latDiff = Math.toRadians(lat_b-lat_a);
        double lngDiff = Math.toRadians(lng_b-lng_a);
        double a = (Math.cos(Math.toRadians(lat_a)) * Math.cos(Math.toRadians(lat_b)) *
                Math.sin(lngDiff / 2) * Math.sin(lngDiff / 2)) + (Math.sin(latDiff / 2) * Math.sin(latDiff / 2));
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        double distance = earthRadius * c;

        int meterConversion = 1609;

        return new Float(distance * meterConversion).floatValue();
    }
}
